/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.arelance.libreriafinal.beans;


import com.arelance.libreriafinal.main.Main;
import com.arelance.libreriafinal.menus.MenuPrincipal;
import com.arelance.libreriafinal.menus.MenuSecundario;
import com.arelance.libreriafinal.vistas.ViewLibro;
import com.arelance.libreriafinal.vistas.VistaDatosLogin;
import com.arelance.libreriafinal.vistas.VistaObtenerLibro;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author manulibra
 */
public class BaseDeDatos {
    private Sesion sesion = Sesion.SESION;
    
    
    public BaseDeDatos() {
        
    }


    
    public void guardar(Main main) throws FileNotFoundException, IOException {
        FileOutputStream fos = new FileOutputStream("datosusuarios.dat");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(main.getListUsers());
        oos.close();

        FileOutputStream fos2 = new FileOutputStream("datoslibros.dat");
        ObjectOutputStream oos2 = new ObjectOutputStream(fos2);
        oos2.writeObject(main.getListBooks());
        oos2.close();
    }

    public boolean add(Usuario usuario,DatosPersonales dp,Main main) {
        Map<Usuario, DatosPersonales> listaUso = main.getListUsers();
        listaUso.put(new Usuario(usuario.getNick(), usuario.getPassword()), new DatosPersonales(dp.getNombre(), dp.getApellido()));
        main.setListUsers(listaUso);
        for (Map.Entry<Usuario, DatosPersonales> entry : main.getListUsers().entrySet()) {
            Usuario key = entry.getKey();
            System.out.println(key);
        }
        return true;
    }

    public boolean login(Usuario usuario,Main main) {
        MenuSecundario ms = new MenuSecundario();
        VistaDatosLogin login = new VistaDatosLogin();
        sesion.setCurrentUser(login.getData());
        boolean entrada = false;
        for (Map.Entry<Usuario, DatosPersonales> entry : main.getListUsers().entrySet()) {
            Usuario key = entry.getKey();
            if (sesion.getCurrentUser().compareTo(key) == 0) {
                entrada = true;
                ms.menuSecundario(main);
//                return entrada;
            }
        }
        if (entrada == false) {
            System.out.println("usuario no valido");
        }
        return entrada;
    }

    public void desLogin(Main main) {
        MenuPrincipal mp = new MenuPrincipal();
        System.out.println("Cerrando sesion");
        mp.menuPrincipal(main);
    }

    public boolean libroA(Main main) {
        Map<Libro, Set<Usuario>> aux = new HashMap<>();
        for (Map.Entry<Libro, Set<Usuario>> entry : main.getListBooks().entrySet()) {
            Libro key = entry.getKey();
            if (!entry.getValue().contains(sesion.getCurrentUser())) {
                System.out.println(key);
            }else{
                aux.put(key, entry.getValue());
            }
        }
        ViewLibro viewLibro = new VistaObtenerLibro();
        Libro libro = viewLibro.getData();
         try {
            if (main.getListBooks().get(libro) == null) {
                throw new NullPointerException();
            } else {
                if(aux.size() < 3){
                    main.getListBooks().get(libro).add(sesion.getCurrentUser());                  
                    return true;
                }else{
                    System.out.println("Tienes que devolver un libro antes de coger otro");
                    return true;
                }
                
            }
        } catch (NullPointerException e) {
            System.out.println("no existe el libro");
        }
        return false;
    }

    public boolean libroD(Main main) {
        for (Map.Entry<Libro, Set<Usuario>> entry :main.getListBooks().entrySet()) {
            Libro key = entry.getKey();
            if (entry.getValue().contains(sesion.getCurrentUser())) {
                System.out.println(key);
            }
        }
        ViewLibro viewLibro = new VistaObtenerLibro();
        Libro libro = viewLibro.getData();
         try {
            if (main.getListBooks().get(libro) == null) {
                throw new NullPointerException();
            } else {
                main.getListBooks().get(libro).remove(sesion.getCurrentUser());
                return true;
            }
        } catch (NullPointerException e) {
            System.out.println("no existe el libro");
        }
        return false;
    }
    
   
}
