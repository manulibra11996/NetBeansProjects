/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.arelance.libreriafinal.services;


import com.arelance.libreriafinal.beans.BaseDeDatos;
import com.arelance.libreriafinal.beans.DatosPersonales;
import com.arelance.libreriafinal.beans.Libro;
import com.arelance.libreriafinal.beans.Usuario;
import com.arelance.libreriafinal.main.Main;
import java.io.IOException;


/**
 *
 * @author manulibra
 */
public class CRUDRepositorio {
    private BaseDeDatos baseDeDatos = new BaseDeDatos();

    public boolean add(Usuario usuario,DatosPersonales dp,Main main) {
        boolean retValue = false;
        if (usuario != null) {
            retValue = baseDeDatos.add(usuario,dp,main);
        }
        return retValue;
    }
    
    public boolean login(Usuario usuario,Main main) {
        boolean retValue = false;
        if (usuario != null) {
            retValue = baseDeDatos.login(usuario,main);
        }
        return retValue;
    }
    
    public void salir(Main main) throws IOException {
        baseDeDatos.guardar(main);
        System.exit(0);
    }

    public void desLogin(Main main) {
       baseDeDatos.desLogin(main);
    }

    public boolean libroA(Main main) {
        boolean retValue = false;
        if (main != null) {
            retValue = baseDeDatos.libroA(main);
        }
        return retValue;
    }

    public boolean libroD(Main main) {
        boolean retValue = false;
        if (main != null) {
            retValue = baseDeDatos.libroD(main);
        }
        return retValue;
    }

}
