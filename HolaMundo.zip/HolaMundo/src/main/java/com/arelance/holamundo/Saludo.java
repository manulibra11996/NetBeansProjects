package com.arelance.holamundo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Manuel
 */
// keyword(Palabra clave): public, class => minusculas siempre
//public class debe de haber una siempre cuyo nombre es el nombre del archivo
//nombres de clase:CamelCase
//Listado modificadores acceso: public, private, protected, package
public class Saludo {
    //metodo
    public static void main(String[] args) {
        System.out.println("Hola mundo");
    }
    
}
