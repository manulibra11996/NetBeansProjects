/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.arelance.holamundo.util;

import java.util.Scanner;

/**
 *
 * @author Manuel
 */
public class FlujosBucles {
    
     private static double getData(String msg){
        Scanner teclado = new Scanner(System.in);
        System.out.println(msg);
        return teclado.nextInt();
    }

    public static void main(String[] args) {

        double x = getData("Inserte el numero x:");
        double y = getData("Inserte el numero y:");
        
        System.out.println("El numero mayor es: " + (int)Math.max(x, y));
        
        System.out.println(Calculadora.sumar(x, y) > 100 ?  (int)Calculadora.sumar(x, y) + " es mayor a 100" : (int)Calculadora.sumar(x, y) + " es menor a 100"); 
        
//        if (Calculadora.sumar(x, y) > 100) {
//            System.out.println((int) Calculadora.sumar(x, y) + " es mayor a 100") ;
//        }else if (resultado < 100){
//            System.out.println((int) Calculadora.sumar(x, y) + " es menor a 100") ;
//        }else{
//            System.out.println((int) Calculadora.sumar(x, y) + " es igual a 100") ;
//        }

//        if( x > y){
//            System.out.println( x + " es mayor que " + y);
//        }else if(x < y){
//            System.out.println( y + " es mayor que " + x);
//        }else{
//            System.out.println( x + " es igual a " + y);
//        }
        
       

//        //And
//        System.out.println(true && true);
//        System.out.println(false && true);
//        System.out.println(true && false);
//        System.out.println(false && false);
//        //or
//        System.out.println(true || true);
//        System.out.println(false || true);
//        System.out.println(true || false);
//        System.out.println(false || false);
    }
   
}
