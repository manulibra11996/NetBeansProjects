package com.arelance.enums;

/**
 *
 * @author Pedro
 */
public enum CategoriasActividad {

    INTERIOR, EXTERIOR;

}
