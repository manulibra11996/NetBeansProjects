package com.arelance.enums;

/**
 *
 * @author Pedro
 */
public enum PaymentMethodsEnum {

    PAYPAL, DEBIT, ACCOUNT;

}
