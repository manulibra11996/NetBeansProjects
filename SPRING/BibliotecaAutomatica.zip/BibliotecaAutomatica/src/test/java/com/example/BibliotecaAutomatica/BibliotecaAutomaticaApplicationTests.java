package com.example.BibliotecaAutomatica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaAutomaticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
