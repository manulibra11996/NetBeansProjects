package com.example.demo.entity;

public enum Departamento {
	
	RRHH,VENTAS,ADMINISTRACION;

}
