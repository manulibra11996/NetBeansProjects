package com.arelance.empleos;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import com.arelance.empleosmodelo.Vacante;

@Configuration
public class ConfigurationConfig {
	  @Bean
	    @Order(2)
	    public Vacante getElement() {
	        return new Vacante("Junior developer","programador java");
	    }

	    @Bean
	    @Order(1)
	    public Vacante getAnotherElement() {
	    	 return new Vacante("Senior developer","programador java");
	    }

} 
