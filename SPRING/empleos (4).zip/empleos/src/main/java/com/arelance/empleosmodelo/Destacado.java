package com.arelance.empleosmodelo;

public enum Destacado {
	SI,NO;
}
