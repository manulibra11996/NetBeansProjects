package com.example.PruebaMapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaMapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
