package com.example.PruebaMapas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaMapasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaMapasApplication.class, args);
	}

}
